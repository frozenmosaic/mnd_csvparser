delete from `cs_menugroup`;
delete from `cs_menucategory`;
delete from `cs_menuitem`;
delete from `cs_categorysize`;
delete from `cs_price`;
delete from `cs_toppinggroup`;
delete from `cs_toppingitems`;
delete from `cs_custom_topping_labels`;
